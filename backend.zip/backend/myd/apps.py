from django.apps import AppConfig


class MydConfig(AppConfig):
    name = 'myd'
